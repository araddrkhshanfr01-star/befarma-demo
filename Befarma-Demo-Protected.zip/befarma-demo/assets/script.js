// حالت‌های فعال فیلدها
    const fieldStates = {
      email: true,
      phone: true,
      password: true,
      birthdate: true,
      google: true
    };

    let currentTheme = 'dark'; // 'dark' یا 'light'
    let currentTab = 'login'; // 'login' یا 'register'

    // کنترل رویت کلمه عبور
    function togglePasswordVisibility() {
      const pwdInput = document.getElementById('pwd-input');
      const eyeIcon = document.getElementById('eye-icon');
      if (pwdInput.type === 'password') {
        pwdInput.type = 'text';
        eyeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18"/>';
      } else {
        pwdInput.type = 'password';
        eyeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>';
      }
    }

    // تغییر تب ورود / ثبت‌نام
    function switchAuthTab(tab) {
      currentTab = tab;
      const btnLogin = document.getElementById('tab-login');
      const btnRegister = document.getElementById('tab-register');
      const cardHeading = document.getElementById('card-heading');
      const cardSubheading = document.getElementById('card-subheading');
      const submitBtnText = document.getElementById('submit-btn-text');

      if (tab === 'login') {
        btnLogin.className = "flex-1 py-2.5 text-xs font-bold rounded-xl transition-all bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md";
        btnRegister.className = "flex-1 py-2.5 text-xs font-semibold rounded-xl transition-all text-gray-400 hover:text-white";
        cardHeading.textContent = "خوش آمدید";
        cardSubheading.textContent = "برای ادامه، لطفا مشخصات کاربری خود را وارد کنید";
        submitBtnText.textContent = "ورود به بفرما";
      } else {
        btnRegister.className = "flex-1 py-2.5 text-xs font-bold rounded-xl transition-all bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md";
        btnLogin.className = "flex-1 py-2.5 text-xs font-semibold rounded-xl transition-all text-gray-400 hover:text-white";
        cardHeading.textContent = "ایجاد حساب در بفرما";
        cardSubheading.textContent = "در کمتر از یک دقیقه عضو خانواده بزرگ ما شوید";
        submitBtnText.textContent = "تکمیل و ثبت‌نام در بفرما";
      }
    }

    // تغییر فیلد از طریق پنل مدیریت
    function toggleField(fieldName) {
      const toggle = document.getElementById(`toggle-${fieldName}`);
      const wrapper = document.getElementById(`field-wrapper-${fieldName}`);
      const isChecked = toggle.checked;
      fieldStates[fieldName] = isChecked;

      if (isChecked) {
        wrapper.classList.remove('hidden');
        wrapper.style.opacity = '0';
        wrapper.style.transform = 'translateY(-8px)';
        setTimeout(() => {
          wrapper.style.opacity = '1';
          wrapper.style.transform = 'translateY(0)';
        }, 10);
      } else {
        wrapper.style.opacity = '0';
        wrapper.style.transform = 'translateY(-8px)';
        setTimeout(() => {
          wrapper.classList.add('hidden');
        }, 200);
      }

      updateActiveCount();
    }

    // به‌روزرسانی تعداد فیلدهای فعال
    function updateActiveCount() {
      const activeCount = Object.values(fieldStates).filter(Boolean).length;
      const countEl = document.getElementById('active-fields-count');
      countEl.textContent = `${activeCount} از ۵ فیلد فعال است`;
      
      // اگر همه غیرفعال شوند، اخطار محترمانه
      if (activeCount === 0) {
        countEl.textContent = "هیچ فیلدی فعال نیست!";
        countEl.className = "font-bold text-rose-300 bg-rose-500/20 px-2.5 py-1 rounded-lg border border-rose-500/30";
      } else {
        countEl.className = "font-bold text-white bg-white/10 px-2.5 py-1 rounded-lg";
      }
    }

    // پریست‌های پیش‌فرض پنل مدیریت
    function applyPreset(type) {
      if (type === 'minimal') {
        setToggleState('email', true);
        setToggleState('phone', false);
        setToggleState('password', true);
        setToggleState('birthdate', false);
        setToggleState('google', true);
      } else if (type === 'all') {
        setToggleState('email', true);
        setToggleState('phone', true);
        setToggleState('password', true);
        setToggleState('birthdate', true);
        setToggleState('google', true);
      }
    }

    function setToggleState(field, state) {
      const toggle = document.getElementById(`toggle-${field}`);
      toggle.checked = state;
      toggleField(field);
    }

    // تغییر تم بین کهکشانی (Dark) و سفید شیشه‌ای (Light)
    function toggleTheme() {
      if (currentTheme === 'dark') {
        setThemeState('light');
      } else {
        setThemeState('dark');
      }
    }

    function setThemeState(theme) {
      const root = document.getElementById('app-root');
      const themeText = document.getElementById('theme-text');
      const themeIcon = document.getElementById('theme-icon');
      const brandTitle = document.getElementById('brand-title');
      const bannerSubtitle = document.getElementById('banner-subtitle');
      const galaxyBg = document.getElementById('galaxy-bg');

      currentTheme = theme;

      if (theme === 'light') {
        root.classList.remove('dark');
        root.classList.add('light-theme');
        root.style.backgroundColor = '#eef2f6';
        root.style.color = '#1e293b';

        themeText.textContent = "تم سفید (White Glass)";
        themeIcon.textContent = "☀️";
        themeIcon.className = "text-amber-500 text-sm";
        brandTitle.classList.remove('text-white');
        brandTitle.classList.add('text-slate-800');
        bannerSubtitle.classList.remove('text-gray-400');
        bannerSubtitle.classList.add('text-slate-600');

        // تغییر استایل هاله‌ها برای تم لایت (روشن‌تر و لطیف‌تر)
        galaxyBg.innerHTML = `
          <div class="absolute -top-24 -right-24 w-[520px] h-[520px] bg-purple-300/40 rounded-full blur-[100px] animate-blob-slow"></div>
          <div class="absolute top-1/3 -left-32 w-[600px] h-[600px] bg-blue-300/40 rounded-full blur-[120px] animate-blob-reverse"></div>
          <div class="absolute -bottom-32 right-1/4 w-[550px] h-[550px] bg-cyan-200/40 rounded-full blur-[110px]"></div>
        `;
      } else {
        root.classList.remove('light-theme');
        root.classList.add('dark');
        root.style.backgroundColor = '#07070d';
        root.style.color = '#f3f4f6';

        themeText.textContent = "تم کهکشانی (Dark)";
        themeIcon.textContent = "🌙";
        themeIcon.className = "text-amber-400 text-sm";
        brandTitle.classList.remove('text-slate-800');
        brandTitle.classList.add('text-white');
        bannerSubtitle.classList.remove('text-slate-600');
        bannerSubtitle.classList.add('text-gray-400');

        // بازگشت به هاله‌های کهکشانی تاریک
        galaxyBg.innerHTML = `
          <div class="absolute -top-24 -right-24 w-[520px] h-[520px] bg-purple-600/35 rounded-full blur-[115px] animate-blob-slow"></div>
          <div class="absolute top-1/3 -left-32 w-[600px] h-[600px] bg-indigo-600/30 rounded-full blur-[130px] animate-blob-reverse"></div>
          <div class="absolute -bottom-32 right-1/4 w-[550px] h-[550px] bg-cyan-500/20 rounded-full blur-[120px] animate-pulse-subtle"></div>
          <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[420px] h-[420px] bg-fuchsia-500/15 rounded-full blur-[110px]"></div>
        `;
      }
    }

    // تغییر چیدمان و دید صفحه‌ها (همزمان، فقط فرم، فقط پنل مدیریت)
    function setViewMode(mode) {
      const authCol = document.getElementById('auth-col');
      const adminCol = document.getElementById('admin-col');
      const btnAll = document.getElementById('view-mode-all');
      const btnAuth = document.getElementById('view-mode-auth');
      const btnAdmin = document.getElementById('view-mode-admin');

      // ریست استایل دکمه‌ها
      [btnAll, btnAuth, btnAdmin].forEach(btn => {
        btn.className = "px-3.5 py-1.5 text-xs font-medium text-gray-400 hover:text-white rounded-xl transition-all";
      });

      if (mode === 'split') {
        btnAll.className = "px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-purple-600 text-white transition-all shadow-sm";
        authCol.className = "lg:col-span-7 transition-all duration-300";
        adminCol.className = "lg:col-span-5 transition-all duration-300";
        authCol.classList.remove('hidden');
        adminCol.classList.remove('hidden');
      } else if (mode === 'auth-only') {
        btnAuth.className = "px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-purple-600 text-white transition-all shadow-sm";
        authCol.className = "lg:col-span-12 max-w-xl mx-auto w-full transition-all duration-300";
        authCol.classList.remove('hidden');
        adminCol.classList.add('hidden');
      } else if (mode === 'admin-only') {
        btnAdmin.className = "px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-purple-600 text-white transition-all shadow-sm";
        adminCol.className = "lg:col-span-12 max-w-xl mx-auto w-full transition-all duration-300";
        adminCol.classList.remove('hidden');
        authCol.classList.add('hidden');
      }
    }

    // هندل ارسال فرم
    function handleFormSubmit(e) {
      e.preventDefault();
      const alertBox = document.getElementById('auth-alert');
      const alertMsg = document.getElementById('alert-msg');
      
      const activeFields = Object.keys(fieldStates).filter(k => fieldStates[k]);
      alertMsg.textContent = `درخواست با موفقیت ثبت شد. فیلدهای پردازش شده: ${activeFields.join('، ')}`;
      alertBox.classList.remove('hidden');

      setTimeout(() => {
        alertBox.classList.add('hidden');
      }, 4000);
    }

    // هندل دکمه ورود گوگل
    function handleGoogleAuth() {
      const alertBox = document.getElementById('auth-alert');
      const alertMsg = document.getElementById('alert-msg');
      alertMsg.textContent = "ارتباط با سرویس Google OAuth برقرار شد...";
      alertBox.classList.remove('hidden');
      setTimeout(() => {
        alertBox.classList.add('hidden');
      }, 3000);
    }